var tr = {
    addButtonLabel: "Add current page to list",
	deleteButtonLabel: "Delete site from the list",
	lockButtonLabel: "Lock site"
};
